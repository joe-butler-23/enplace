import { chromium } from "<repo>/node_modules/playwright/index.mjs";
import { readFile, writeFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import { isDeepStrictEqual } from "node:util";
const [sourcePath, fixturePath, outputPath] = process.argv.slice(2);
const source = await readFile(sourcePath, "utf8"), raw = await readFile(fixturePath, "utf8"), cases = JSON.parse(raw);
const hash = text => createHash("sha256").update(text).digest("hex");
const browser = await chromium.launch({headless:true});
try {
 const page = await browser.newPage();
 await page.route("**/*", route => route.abort());
 const extracted = await page.evaluate(async ({source,cases}) => {
  const {clipRecipes} = await import("data:text/javascript;base64,"+btoa(unescape(encodeURIComponent(source))));
  return cases.map(c => {try {return {name:c.name,actual:clipRecipes(new DOMParser().parseFromString(c.html,"text/html"),{url:"https://example.test/pilot"})};}catch(e){return {name:c.name,error:e.message,actual:[]};}});
 },{source,cases});
 const results = extracted.map((r,i)=>{const c=cases[i];const ok=!r.error && (c.gate === "no-invented-method" ? r.actual.every(a=>a.instructions.length===0 && a.missing.includes("instructions")) : r.actual.length===c.expected.length && c.expected.every((e,j)=>Object.entries(e).every(([k,v])=>isDeepStrictEqual(r.actual[j][k],v))));return {...c,...r,ok};});
 await writeFile(outputPath,JSON.stringify({sourceSHA256:hash(source),fixtureSHA256:hash(raw),browser:browser.version(),results},null,2));
 console.log(JSON.stringify({pass:results.filter(r=>r.ok).length,total:results.length,failed:results.filter(r=>!r.ok).map(r=>({name:r.name,actual:r.actual,error:r.error}))},null,2));
}finally {await browser.close();}

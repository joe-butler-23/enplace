# Structural RecipeClipper pilot verdict

**REJECT B; RETAIN SAFETY BASELINE A.** The frozen behavioral pilot passed, but the parent broader oracle found a method-substitution regression and two false complete recipes. The stop rule is reached. No further corrections, candidate full-corpus run, or candidate timing run. No tracked source was edited by this worker.

## Frozen evidence

- Safety source: `/tmp/clipper-enplace-safety.js`, SHA256 `2075e25106ec52b88e4b266ab97eddb15c4330d100dbd9be1145445083bf81d0`.
- Fixture: `/tmp/clipper-structural-frozen.json`, SHA256 `0bd2e5c2563a3faedb3e4eb956a5a0d8d4630a3e98d1f5e1436bf4275c272bad`. Unchanged throughout.
- Driver: `/tmp/clipper-pilot.mjs`.
- Browser: Chromium `145.0.7632.6` through project Playwright, Node 24.19.0. Requests blocked by driver.
- Final source: `/tmp/clipper-structural-candidate.js`, SHA256 `4c44805af4b61be74ec3cb7dbf91af447a48040a23fd82a083ab07b4899b5059`.

## Results

Safety baseline 16/24; final candidate 21/24. All 16 baseline passing gates preserved. Five gains:

- list-unlabelled-prose
- table-unlabelled-prose
- list-unlabelled-inline-bereiding
- uncaptioned-list-prose
- uncaptioned-table-prose

Manually compared source and raw outputs for the gains and printed two-recipe positive. Ingredient quantities, units and punctuation are unchanged. Methods retain source order. The printed pair remains separate, including its dressing group, descriptions and Whisk step. All pinned negatives preserve their declared gate. Two allowed zero-method partials now gain their owned heading title (`Shopping list`, `Related recipes`); this is the only full-API delta among baseline passing cases, and neither gains instructions or completeness.

Three unchanged baseline gaps remain, not repaired:
- `two-independent-articles-mixed-rows`: both candidates retain page title Lunch recipes instead of article H2 titles. Their ingredients and methods remain separate.
- `owned-recipe-excludes-hidden-and-related`: visible recipe title remains empty. Hidden and related material do not enter the recipe.
- `inline-bereiding-prose`: explicit inline-caption reader returns only the first paragraph and still omits Stir well and serve. The shared shape path does not supersede an already read explicit instruction field.

## Mechanism and static result

The separate `quantityBlock`, `proseRecipes`, and final prose-only fallback orchestration are deleted. `ingredientRows` now admits list, table and printed bold-break rows. One shaped-field scan records rows and procedures with their heading owner. One grouping/reconstruction path supplies ingredient labels, owned prose, descriptions and candidate names. `markup` returns candidate arrays, so the ordinary final candidate loop handles printed and other shaped recipes alike. Existing explicit selectors/captions remain first. No site-specific selectors or vocabulary were added.

Safety source: **60,042 bytes / 796 physical LOC**. Final: **59,913 bytes / 793 physical LOC**. Delta: **-129 bytes / -3 LOC**. Neither source was minified. The entire numeric identity section and `renderedRows` implementation remain byte-identical to the safety baseline. `node --check` passes.

Static caution: this changes shaped-field candidate cardinality, grouping and heading ownership. Pilot success does not establish correctness for every publisher. In particular, broad document-order heading ownership and fallback ordered-procedure association need the parent's source-backed corpus review. No full corpus, hidden pages, timing, app build or PWA import was run by this worker.

## Bounded iterations

1. Initial shared candidate: 20/24. One baseline positive regressed: printed candidates took article H1 and Serves four. became an ingredient label. No new quantity, method-order, ingredient cross-contamination, or pinned-negative failure.
2. Correction 1 fixes these exact reconstruction defects: multiple source-owned candidates use their own titles; intro prose does not become a leading group label without caption evidence. 21/24.
3. Correction 2 fixes static preservation defects: explicit description/name precedence on card enrichment; restores the old method-caption normalization accidentally shortened during refactoring. 21/24. No corrections remain.

## Artifacts and handoff

- Final candidate: `/tmp/clipper-structural-candidate.js`.
- Initial and correction-1 snapshots: `/tmp/clipper-structural-candidate-1.js`, `/tmp/clipper-structural-candidate-2.js`.
- Raw runs: `/tmp/clipper-pilot-baseline.json`, `/tmp/clipper-pilot-candidate-1.json`, `/tmp/clipper-pilot-candidate-2.json`, `/tmp/clipper-pilot-candidate-final.json`.
- Static diff: `/tmp/clipper-structural.diff`.
- Machine-readable comparison and hashes: `/tmp/clipper-structural-static.json`.
- Verdict: `/tmp/clipper-structural-verdict.md`.

Parent rejected candidate B after broader-oracle checks. Do not adopt or continue candidate sampling. If any full-corpus safety, source-fidelity, complexity or timing gate fails, retain the safety baseline rather than patching this candidate further. Reopen only with a newly preregistered mechanism or new evidence that resolves the exact observed ownership/procedure boundary failure; do not repeat the same candidate with extra publisher heuristics. Bead jrv.2 stays open/in_progress for parent integration; no commit or close by this worker.

## Size-quality clarification requested by parent

The whole-file counts above are exact, but do not show executable-code reduction. Replacing the obsolete 3-line shapedFields comment (370 bytes) with its 2-line accurate description (186 bytes) saved 184 bytes during correction 2. Retaining the old comment verbatim would give 60,097 bytes, **55 bytes above baseline**. The obsolete comment incorrectly limits results to one list. The source is not minified. However, the whole-file byte threshold therefore depends on this comment change. Parent should not treat that as demonstrated executable simplification.

A transparent, non-lexical diagnostic excluding blank lines and full-line `//` comments gives baseline 690 lines / 50,913 bytes versus candidate 695 lines / 51,650 bytes (**+5 lines / +737 bytes**). This diagnostic retains inline comments and is not a JS minifier. The old prose-only path is genuinely deleted, but the shared reconstruction grew. If the no-comment-threshold-gaming requirement rejects this candidate, retain the safety baseline; two corrections are exhausted. No source edit followed this clarification.

## Final parent rejection: broader oracle failed

The parent supplied these results after the frozen pilot. This worker read the raw outputs and failure log; it did not rerun or change them.

- Legacy suite: **116/117 pass, one regression**, `/tmp/clipper-legacy-candidate.log`. `blank structured fields allow same-card enrichment without replacing real values` expected `Chop the carrots.`, `Simmer for 15 minutes.` but candidate returned `Freeze leftovers.`, `120 kcal`. The shared prose association substituted notes and nutrition for the method.
- Independent recipe-like negatives: **A 2/2 pass; B 0/2 pass**. `product-specification-with-prose` promotes `2 kg weight`, `3 litre capacity`, `400 W power` plus `Order now for free delivery.` into a complete recipe. `shopping-list-with-prose` promotes `1 bag flour`, `2 bottles milk`, `3 onions` plus `Pick these up on your way home.` into a complete recipe.
- Fixtures `/tmp/clipper-adversarial-prose.json`; raw evidence `/tmp/clipper-adversarial-baseline.json`, `/tmp/clipper-adversarial-candidate.json`. Negative-fixture SHA256 `9e48aaca7015149e774bf48c733552df4dc34626fa76a46c80138574ee49d316`; candidate SHA256 matches the final frozen candidate above.

**Decision: REJECT B and retain A.** Quantity-like rows followed by heading-owned paragraphs are insufficient evidence that the paragraphs are a cooking method. The failure is structural, not a reason to add product, shopping or publisher-specific exclusions. Both allowed corrections were already used. The executable-size caveat above independently prevents a clean subtraction claim: executable-only diagnostic +737 bytes/+5 lines, while the whole-file decrease depends on deleted/reworded comments.

Reopen only with a newly preregistered mechanism or new evidence that resolves both method ownership and recipe admission without vocabulary patches, while showing genuine executable simplification. Parent owns retention documentation and final tracker closeout; no further tracker edits by this worker.
